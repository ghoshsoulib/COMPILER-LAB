#include <bits/stdc++.h>
#include <iomanip>
using namespace std;

struct Node {
	bool nullable;
	set<int> firstpos;
	set<int> lastpos;
	set<int> followpos;
	int index;
	char ch;
	struct Node *left;
	struct Node *right;
};	
struct dfastate_dfa {
	bool final;
	bool start;
	set<int> contents;
	vector< pair<char, dfastate_dfa*> > transitions;
};
Node *buildNode(Node *LEFT, Node *RIGHT, char op) {
	Node *parent = new Node;		
	parent->ch = op;
	parent->left = LEFT;
	parent->right = RIGHT;	
	parent->index = -1;
	parent->nullable = false;
	parent->firstpos.clear();
	parent->lastpos.clear();
	parent->followpos.clear();
	return parent;
};
int prec(char c) {
    if(c == '*') return 3; 
    else if(c == '.') return 2; 
    else if(c == '|') return 1; 
    else return -1; 
} 
string infixToPostfix(string s) {
    stack<char> st; 
    st.push('N'); 
    int l = s.length(); 
    string ns; 
    for(int i = 0; i < l; i++) {
        if((s[i] >= 'a' && s[i] <= 'z') || (s[i] >= 'A' && s[i] <= 'Z') || (s[i] == '#')) 
            ns += s[i]; 
        else if(s[i] == '(') 
            st.push('('); 
        else if(s[i] == ')') {
            while(st.top() != 'N' && st.top() != '(') { 
                char c = st.top(); 
                st.pop(); 
                ns += c; 
            } 
            if(st.top() == '(') { 
                char c = st.top(); 
                st.pop(); 
            } 
        } 
        else { 
            while(st.top() != 'N' && prec(s[i]) <= prec(st.top())) { 
                char c = st.top(); 
                st.pop(); 
                ns += c; 
            } 
            st.push(s[i]); 
        } 
  
    } 
    while(st.top() != 'N') {
        char c = st.top(); 
        st.pop(); 
        ns += c; 
    } 
  
    return ns;
} 

Node* buildSyntaxTree(stack<char> &st1, set<char> &inputAlphabet) {
	stack<Node *> st2;
	Node *node;
	while(!st1.empty()) {
		node = NULL;	
		char ch = st1.top();			
		if(ch == '*') {
			Node *LEFT = st2.top();
			st2.pop();			
			node = buildNode(LEFT, NULL, ch);
		} else if(ch=='|' || ch =='.') {
			Node *RIGHT= st2.top();
			st2.pop();
			Node *LEFT = st2.top();
			st2.pop();		
			node = buildNode(LEFT, RIGHT, ch); 
		} else {
			node = buildNode(NULL, NULL, ch);
			if (ch != '#')
				inputAlphabet.insert(ch);
		}
		st2.push(node);
		st1.pop();
	}
	return st2.top();
}

void assignIndices(Node *root, int *index, vector<Node *> &indexedNodes) {
	if (root == NULL) 
		return;
	if (root->left == NULL && root->right == NULL) {
		root->index = *index;
		*index = *index + 1;
		indexedNodes.push_back(root);
	}
	if (root->left != NULL) {
		assignIndices(root->left, index, indexedNodes);
	}
	if (root->right != NULL) {
		assignIndices(root->right, index, indexedNodes);
	}
}

void takeUnion(set<int> &s1, set<int> &s2) {
	set<int>::iterator it;

	for(it = s2.begin(); it != s2.end(); it++) {
		s1.insert(*it);
	}
}

void computeFunctions(Node *root) {
	if (root == NULL)
		return;
	if (root->left != NULL)
		computeFunctions(root->left);
	if (root->right != NULL)
		computeFunctions(root->right);
	if (root->left == NULL && root->right == NULL) {
		root->nullable = false;
		root->firstpos.insert(root->index);
		root->lastpos.insert(root->index);
	} 
	if (root->ch == '|') {
		root->nullable = root->left->nullable || root->right->nullable;
		set<int>::iterator it;
		// root->firstpos
		takeUnion(root->firstpos, root->left->firstpos);
		takeUnion(root->firstpos, root->right->firstpos);
		// root->lastpos
		takeUnion(root->lastpos, root->left->lastpos);
		takeUnion(root->lastpos, root->right->lastpos);
	}
	if (root->ch == '.') {
		root->nullable = root->left->nullable && root->right->nullable;
		set<int>::iterator it;	
		// root->firstpos
		takeUnion(root->firstpos, root->left->firstpos);
		if (root->left->nullable) {
			takeUnion(root->firstpos, root->right->firstpos);
		}
		// root->lastpos
		takeUnion(root->lastpos, root->right->lastpos);
		if (root->right->nullable) {
			takeUnion(root->lastpos, root->left->lastpos);
		}
	}
	if (root->ch == '*') {
		root->nullable = true;
		set<int>::iterator it;	
		takeUnion(root->firstpos, root->left->firstpos);
		takeUnion(root->lastpos, root->left->lastpos);
	}
}

void computeFollowpos(Node *root, vector<Node *> &indexedNodes) {
	if (root == NULL)
		return;
	if (root->left != NULL)
		computeFollowpos(root->left, indexedNodes);
	if (root->right != NULL)
		computeFollowpos(root->right, indexedNodes);
	
	if (root->ch == '.') {
		set<int>::iterator it_o, it_i;
		for (it_o = root->left->lastpos.begin(); it_o != root->left->lastpos.end(); it_o++) {
			for (it_i = root->right->firstpos.begin(); it_i != root->right->firstpos.end(); it_i++) {
				indexedNodes.at(*it_o - 1)->followpos.insert(*it_i);
			}
		}
	}
	if (root->ch == '*') {
		set<int>::iterator it_o, it_i;
		for (it_o = root->lastpos.begin(); it_o != root->lastpos.end(); it_o++) {
			for (it_i = root->firstpos.begin(); it_i != root->firstpos.end(); it_i++) {
				indexedNodes.at(*it_o - 1)->followpos.insert(*it_i);
			}
		}
	}
}

stack<char> stringToStack(string s) {
	int len = s.size();
	stack<char> st;
	for(int i = len - 1; i >= 0; i--) {
		st.push(s[i]);
	}	
	return st;
}

void printSet(string name, set<int> &s) {
	int len = s.size();
	cout << name << ": {";
	set<int>::iterator it;
	for (it = s.begin(); it != s.end(); it++) {
		cout << *it;
		if (len > 1)
			cout << ", ";
		len--;
	}
	cout << "}";
}

void printPreorder(Node* node) {
    if (node == NULL) 
        return; 
	set<int>::iterator it;
	cout << "\n------------------------------------------------------------------------------------------------------------------------------------\n";
    cout << "Ch: " << node->ch << ",\t";
	cout << "Index: " << setw(2) << node->index << ",\t";
	cout << "Nullable: " << node->nullable << ",\t";
	printSet("Firstpos", node->firstpos);
	cout << ",\t\t";
	printSet("Lastpos", node->lastpos);
	cout << ",\t\t";
	cout << "Left Child: ";
	if (node->left != NULL) {
		cout << node->left->ch << ",\t";
	} else {
		cout << "NULL,\t";
	}
	cout << "Right Child: ";
	if (node->right != NULL) {
		cout << node->right->ch << ",\t";
	} else {
		cout << "NULL,\t";
	}
	cout << endl;
    printPreorder(node->left);
    printPreorder(node->right); 
}
void printIndexedNodes(vector<Node *> &indexedNodes) {
	cout << "\nINDEX NODES AND THEIR FUNCTIONALITIES \n\n";
	vector<Node *>::iterator it1;
	set<int>::iterator it;
	for (it1 = indexedNodes.begin(); it1 != indexedNodes.end(); it1++) {
		Node *node = *it1;
		cout << "\n----------------------------------------------------------------------------------------------------------------------------\n";
		cout << "Ch: " << node->ch << ", ";
		cout << "\n----------------------------------------------------------------------------------------------------------------------------\n";
		cout << "Index: " << node->index << ", ";
		cout << "\n----------------------------------------------------------------------------------------------------------------------------\n";
		cout << "Nullable: " << node->nullable << ", ";
		cout << "\n----------------------------------------------------------------------------------------------------------------------------\n";
		printSet("Firstpos", node->firstpos);
		cout << ", ";
		printSet("Lastpos", node->lastpos);
		cout << ", ";
		printSet("Followpos", node->followpos);
		cout << "\n----------------------------------------------------------------------------------------------------------------------------\n";
		cout << endl;
	}
}

dfastate_dfa *builddfastate_dfa(set<int> &contents, bool final, bool start) {
	dfastate_dfa *state = new dfastate_dfa;
	set<int>::iterator it;
	for (it = contents.begin(); it != contents.end(); it++) 
		state->contents.insert(*it);
	state->final = final;
	state->start = start;
	return state;
}

bool inside_that(set<dfastate_dfa *> &dfastate_dfas, dfastate_dfa *next, dfastate_dfa **match) {
	set<dfastate_dfa *>::iterator it1;
	set<int>::iterator it2;
	int not_cur = 0;
	for (it1 = dfastate_dfas.begin(); it1 != dfastate_dfas.end(); it1++) {
		if ((*it1)->contents.size() == next->contents.size()) {
			not_cur = 0;
			for (it2 = next->contents.begin(); it2 != next->contents.end(); it2++) {
				if ((*it1)->contents.find(*it2) == (*it1)->contents.end()) {
					not_cur = 1;
					break;
				}
			}
			if (not_cur == 0) {
				*match = *it1;
				return true;
			}
		}
	}
	return false;
}

void dfa_in_making(Node *root, vector<Node *> &indexedNodes, set<dfastate_dfa *> &dfastate_dfas, 
				set<char> &inputAlphabet) {
	dfastate_dfa *start_state = builddfastate_dfa(root->firstpos, false, true);
	dfastate_dfas.insert(start_state);
	set<char>::iterator it_out;
	set<int>::iterator it_inn, it_fol;
	set<dfastate_dfa *> markedStates;
	while (!dfastate_dfas.empty()) {
		dfastate_dfa *temp = *(dfastate_dfas.begin());
		if (temp->contents.empty()) {
			dfastate_dfas.erase(dfastate_dfas.begin());
			continue;
		}
		dfastate_dfa *new_temp = builddfastate_dfa(temp->contents, temp->final, temp->start);
		dfastate_dfas.erase(dfastate_dfas.begin());
		markedStates.insert(new_temp);
		for(it_out = inputAlphabet.begin(); it_out != inputAlphabet.end(); it_out++) {
			set<int> next_state_on_it; 
			next_state_on_it.clear();
			for(it_inn = new_temp->contents.begin(); it_inn != new_temp->contents.end(); it_inn++) {
				if (*it_out == indexedNodes.at((*it_inn) - 1)->ch) {
					set<int> fol = indexedNodes.at((*it_inn) - 1)->followpos;
					for (it_fol = fol.begin(); it_fol != fol.end(); it_fol++) {
						next_state_on_it.insert(*it_fol);
					}
				}
			}
			dfastate_dfa *next = builddfastate_dfa(next_state_on_it, false, false);
			dfastate_dfa *match = NULL;
			if (inside_that(dfastate_dfas, next, &match) == true) {
				next = match;
			} else if (inside_that(markedStates, next, &match) == true) {
				next = match;
			} else {
				dfastate_dfas.insert(next);
			}
			new_temp->transitions.push_back(make_pair(*it_out, next));
		}
	}
	set<dfastate_dfa *>::iterator s_it;
	vector< pair<char, dfastate_dfa *> >::iterator trans;
	for (s_it = markedStates.begin(); s_it != markedStates.end(); s_it++) {
		set<int>::iterator it2;
		for (it2 = (*s_it)->contents.begin(); it2 != (*s_it)->contents.end(); it2++) {
			if (*it2 == indexedNodes.size()) {
				(*s_it)->final = true;
				break;
			}
		}
		dfastate_dfas.insert(*s_it);
	}
}

void show_dfa(set<dfastate_dfa *> &dfastate_dfas) {
	cout << "\nThe DFA transitions are:\n\n";
	cout << "================================================================================================================================\n";
	set<dfastate_dfa *>::iterator it;
	vector< pair<char, dfastate_dfa*> >::iterator it_tran;
	for (it = dfastate_dfas.begin(); it != dfastate_dfas.end(); it++) {
		if ((*it)->start && (*it)->final) {
			cout << "(Start) (Final)\t";
		} else if ((*it)->start) {
			cout << "(Start)        \t";
		} else if ((*it)->final) {
			cout << "(Final)        \t";
		} else {
			cout << "               \t";
		}
		printSet("State", (*it)->contents);
		for (it_tran = ((*it)->transitions).begin(); it_tran != ((*it)->transitions).end(); it_tran++) {
			cout << "\t\t";
			string trans_name(1, it_tran->first);
			printSet(trans_name, ((*it_tran).second)->contents);
		}
		cout << endl;
		cout << "----------------------------------------------------------------------------------------------------------------------------\n";
	}

	cout << "================================================================================================================================\n";
	cout << "\n";
}

void testInput(set<dfastate_dfa *> &dfastate_dfas, string input) {
	dfastate_dfa *curr;
	set<dfastate_dfa *>::iterator it;
	for(it = dfastate_dfas.begin(); it != dfastate_dfas.end(); it++) {
		if ((*it)->start == true) {
			curr = *it;
			break;
		}
	}
	printSet("Start", curr->contents);
	for (int i = 0; i < input.size(); i++) {
		vector< pair<char, dfastate_dfa *> >::iterator tmp;
		int count = 0;
		for (tmp = (curr->transitions).begin(); tmp != (curr->transitions).end(); tmp++) {
			if (tmp->first == input[i]) {
				set<int> temp;
				set<int>::iterator it1;
				for (it1 = (tmp->second)->contents.begin(); it1 != (tmp->second)->contents.end(); it1++) {
					temp.insert(*it1);
				}
				if (temp.empty()) {
					curr = NULL;
					break;
				}
				dfastate_dfa *next = builddfastate_dfa(temp, false, false);
				dfastate_dfa *match = NULL;
				inside_that(dfastate_dfas, next, &match);
				curr = match;
				break;
			}
			count++;
		}
		if (count == (curr->transitions).size()) {
			curr = NULL;
			break;
		}
		if (curr != NULL) {
			printSet(" --> ", curr->contents);
		}
	}
	if (curr == NULL || ((curr != NULL) && curr->final == false)) {
		cout << " (Non final state occured atlast)";
		cout << "\n\t\tString rejected by the DFA\n";
	} else {
		cout << " (Final state occured at last)";
		cout << "\n\t\tString accepted by the DFA\n";
	}
}

/***************************************Main Function *****************************************/

int main() {
	int index = 1;
	vector<Node *> indexedNodes;
	set<char> inputAlphabet;	
	cout << "OR - |\nAND - .\nClosure - *\n";
	string s;
	cout << "Enter the regular expression: ";
	cin >> s;
	s = s + ".#";
	s = infixToPostfix(s);
	stack<char> st =stringToStack(s);
	Node *root = buildSyntaxTree(st, inputAlphabet);
	assignIndices(root, &index, indexedNodes);
	computeFunctions(root);
	computeFollowpos(root, indexedNodes);
	cout << "\nTSYNTAX TREE IS AS FOLLOWS:\n\n";
	printPreorder(root);
	printIndexedNodes(indexedNodes);
	set<dfastate_dfa *> dfastate_dfas;
	dfa_in_making(root, indexedNodes, dfastate_dfas, inputAlphabet);
	show_dfa(dfastate_dfas);
	int i;
	i = 1;
	while(i){
		int x;
		cout << "Press 1 to check OR Press 0 to exit\n";
		cin >> x;
		if(x != 0){
		string input;
		cout << "Enter the string to verify: ";
		cin >> input;
		cout << "\n";
		testInput(dfastate_dfas, input);
		}
		i = x;
	}
	cout << "\n*****************************THANK YOU*********************************\n";
	return 0;
} 		
